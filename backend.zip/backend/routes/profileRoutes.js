import express from "express";
import authMiddleware from "../middleware/auth.js";
import Profile from "../models/Profile.js";

const router = express.Router();

// Save or Update Profile (Authenticated User)
router.post("/", authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;

        const profileData = {
            userId,
            name: req.body.name,
            email: req.body.email,
            phone: req.body.phone,
            gender: req.body.gender,
            location: req.body.location,
            hometown: req.body.hometown,
            dob: req.body.dob,
            height: req.body.height,
            maritalStatus: req.body.maritalStatus,
            about: req.body.about,
            languages: req.body.languages,
            interests: req.body.interests,
            education: req.body.education,
            university: req.body.university,
            profession: req.body.profession,
            company: req.body.company,
            familyType: req.body.familyType,
            siblings: req.body.siblings,
            fatherOccupation: req.body.fatherOccupation,
            motherOccupation: req.body.motherOccupation,
            familyValues: req.body.familyValues,
            familyBackground: req.body.familyBackground,
            diet: req.body.diet,
            drinking: req.body.drinking,
            smoking: req.body.smoking,
            fitness: req.body.fitness,
            prefAgeRange: req.body.prefAgeRange,
            prefHeightRange: req.body.prefHeightRange,
            prefEducation: req.body.prefEducation,
            prefOccupation: req.body.prefOccupation,
            partnerPreferences: req.body.partnerPreferences,
            community: req.body.community,
            jobLocation: req.body.jobLocation,
            instagram: req.body.instagram,
            linkedin: req.body.linkedin,
            facebook: req.body.facebook,
            youtube: req.body.youtube,
            profilePhoto: req.files["profilePhoto"] ? req.files["profilePhoto"][0].path : null,
            additionalPhotos: req.files["additionalPhotos"] ? req.files["additionalPhotos"].map(file => file.path) : []
        };

        let profile = await Profile.findOne({ userId });

        if (profile) {
            profile = await Profile.findOneAndUpdate({ userId }, { $set: profileData }, { new: true });
            return res.status(200).json({ message: "Profile updated successfully!", profile });
        }

        profile = new Profile(profileData);
        await profile.save();
        res.status(201).json({ message: "Profile created successfully!", profile });

    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
});

// Get Profile Data (Authenticated User)
router.get("/", authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;
        const profile = await Profile.findOne({ userId });

        if (!profile) return res.status(404).json({ message: "Profile not found" });

        res.status(200).json(profile);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
});

export default router;