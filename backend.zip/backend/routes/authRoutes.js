import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/Users.js";
import Profile from "../models/Profile.js";
import dotenv from "dotenv";

dotenv.config();

const router = express.Router();

// User Registration
router.post('/register', async (req, res) => {
    try {
        const {
            name, email, password, phone, gender, dob, location, community, jobLocation,
            hometown, height, maritalStatus, about, languages, interests, education, university,
            profession, company, familyType, siblings, fatherOccupation, motherOccupation,
            familyValues, familyBackground, diet, drinking, smoking, fitness, prefAgeRange,
            prefHeightRange, prefEducation, prefOccupation, partnerPreferences
        } = req.body;

        const existingUser = await User.findOne({ email });
        if (existingUser) return res.status(400).json({ message: "User already exists" });

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({
            name, email, password: hashedPassword, phone, gender, dob, location, community, jobLocation
        });
        await newUser.save();

        // Create a profile for the user
        const newProfile = new Profile({
            userId: newUser._id,
            name,
            email,
            phone,
            gender,
            location,
            hometown,
            dob,
            height,
            maritalStatus,
            about,
            languages,
            interests,
            education,
            university,
            profession,
            company,
            familyType,
            siblings,
            fatherOccupation,
            motherOccupation,
            familyValues,
            familyBackground,
            diet,
            drinking,
            smoking,
            fitness,
            prefAgeRange,
            prefHeightRange,
            prefEducation,
            prefOccupation,
            partnerPreferences,
            community,
            jobLocation
        });
        await newProfile.save();

        res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
});

// User Login (Return Full Profile)
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ message: "Invalid credentials" });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

        const profile = await Profile.findOne({ userId: user._id });
        if (!profile) return res.status(404).json({ message: "Profile not found" });

        res.status(200).json({
            token,
            user: {
                _id: profile._id,
                name: profile.name,
                email: profile.email,
                gender: profile.gender
            }
        });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
});

export default router;